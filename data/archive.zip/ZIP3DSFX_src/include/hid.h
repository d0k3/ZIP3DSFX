#pragma once

u32 wait_key (void);
void wait_any_key (void);
