#pragma once

u32 wait_key (void);
